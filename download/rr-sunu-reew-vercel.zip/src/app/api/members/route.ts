import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// Get all members (admin) or register new member
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')
    const role = searchParams.get('role')
    const regionId = searchParams.get('regionId')
    const residenceType = searchParams.get('residenceType')

    const where: Record<string, unknown> = {}
    if (status) where.status = status
    if (role) where.role = role
    if (regionId) where.regionId = regionId
    if (residenceType) where.residenceType = residenceType

    const members = await db.member.findMany({
      where,
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        phone: true,
        photo: true,
        dateOfBirth: true,
        placeOfBirth: true,
        address: true,
        cniNumber: true,
        role: true,
        status: true,
        membershipNumber: true,
        membershipDate: true,
        residenceType: true,
        country: true,
        cityAbroad: true,
        hasVoterCard: true,
        voterCardNumber: true,
        createdAt: true,
        region: { select: { id: true, name: true } },
        department: { select: { id: true, name: true } },
        commune: { select: { id: true, name: true } },
        _count: {
          select: {
            contributions: true,
            donations: true,
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({ members })
  } catch (error) {
    console.error('Get members error:', error)
    return NextResponse.json({ error: 'Erreur lors de la récupération des membres' }, { status: 500 })
  }
}

// Register new member
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { 
      email, 
      password, 
      firstName, 
      lastName, 
      dateOfBirth, 
      placeOfBirth,
      address, 
      phone, 
      cniNumber,
      photo,
      // Type de résidence
      residenceType,
      isDiaspora,
      // Pour les résidents au Sénégal
      regionId,
      departmentId,
      communeId,
      // Pour la diaspora
      country,
      cityAbroad,
      // Carte d'électeur
      hasVoterCard,
      voterCardNumber,
    } = body

    // Validation des champs obligatoires
    if (!email || !password || !firstName || !lastName || !dateOfBirth || !placeOfBirth || !address || !phone || !cniNumber) {
      return NextResponse.json({ error: 'Tous les champs obligatoires doivent être remplis' }, { status: 400 })
    }

    // Check if email already exists
    const existing = await db.member.findUnique({
      where: { email: email.toLowerCase() }
    })

    if (existing) {
      return NextResponse.json({ error: 'Cet email est déjà utilisé' }, { status: 400 })
    }

    // Déterminer le type de résidence
    const memberResidenceType = residenceType || (isDiaspora ? 'diaspora' : 'senegal')

    // Validation spécifique selon le type de résidence
    if (memberResidenceType === 'senegal') {
      if (!regionId || !departmentId || !communeId) {
        return NextResponse.json({ error: 'La région, le département et la commune sont obligatoires pour les résidents au Sénégal' }, { status: 400 })
      }
    } else {
      if (!country || !cityAbroad) {
        return NextResponse.json({ error: 'Le pays et la ville de résidence sont obligatoires pour la diaspora' }, { status: 400 })
      }
    }

    // Validation carte d'électeur
    if (hasVoterCard && !voterCardNumber) {
      return NextResponse.json({ error: 'Le numéro de carte d\'électeur est obligatoire si vous en possédez une' }, { status: 400 })
    }

    const encodedPassword = Buffer.from(password).toString('base64')

    const member = await db.member.create({
      data: {
        email: email.toLowerCase(),
        password: encodedPassword,
        firstName,
        lastName,
        dateOfBirth,
        placeOfBirth,
        address,
        phone,
        cniNumber,
        photo: photo || null,
        residenceType: memberResidenceType,
        // Champs pour les résidents au Sénégal
        regionId: memberResidenceType === 'senegal' ? regionId : null,
        departmentId: memberResidenceType === 'senegal' ? departmentId : null,
        communeId: memberResidenceType === 'senegal' ? communeId : null,
        // Champs pour la diaspora
        country: memberResidenceType === 'diaspora' ? country : null,
        cityAbroad: memberResidenceType === 'diaspora' ? cityAbroad : null,
        // Carte d'électeur
        hasVoterCard: hasVoterCard || false,
        voterCardNumber: hasVoterCard ? voterCardNumber : null,
        role: 'member',
        status: 'pending',
      }
    })

    return NextResponse.json({ 
      message: 'Inscription réussie. Votre compte est en attente de validation.',
      memberId: member.id 
    })
  } catch (error) {
    console.error('Register error:', error)
    return NextResponse.json({ error: 'Erreur lors de l\'inscription' }, { status: 500 })
  }
}

// Update member status (admin)
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json()
    const { id, status, role } = body

    const updateData: Record<string, unknown> = {}
    if (status) {
      updateData.status = status
      if (status === 'approved') {
        // Generate membership number
        const count = await db.member.count({ where: { status: 'approved' } })
        const membershipNumber = `RR-${String(count + 1).padStart(6, '0')}`
        updateData.membershipNumber = membershipNumber
        updateData.membershipDate = new Date()
      }
    }
    if (role) updateData.role = role

    const member = await db.member.update({
      where: { id },
      data: updateData,
    })

    return NextResponse.json({ member })
  } catch (error) {
    console.error('Update member error:', error)
    return NextResponse.json({ error: 'Erreur lors de la mise à jour' }, { status: 500 })
  }
}
