import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// Login
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email, password } = body

    if (!email || !password) {
      return NextResponse.json({ error: 'Email et mot de passe requis' }, { status: 400 })
    }

    const encodedPassword = Buffer.from(password).toString('base64')
    
    const member = await db.member.findFirst({
      where: {
        email: email.toLowerCase(),
        password: encodedPassword,
      },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        phone: true,
        photo: true,
        role: true,
        status: true,
        membershipNumber: true,
        membershipDate: true,
        residenceType: true,
        country: true,
        cityAbroad: true,
        region: { select: { id: true, name: true } },
        department: { select: { id: true, name: true } },
        commune: { select: { id: true, name: true } },
      }
    })

    if (!member) {
      return NextResponse.json({ error: 'Identifiants incorrects' }, { status: 401 })
    }

    if (member.status !== 'approved') {
      return NextResponse.json({ error: 'Votre compte n\'est pas encore validé' }, { status: 403 })
    }

    return NextResponse.json({ member })
  } catch (error) {
    console.error('Auth error:', error)
    return NextResponse.json({ error: 'Erreur de connexion' }, { status: 500 })
  }
}
