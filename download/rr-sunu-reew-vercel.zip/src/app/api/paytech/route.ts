import { NextRequest, NextResponse } from 'next/server'

// PayTech API configuration
const PAYTECH_API_KEY = process.env.PAYTECH_API_KEY || 'your_api_key'
const PAYTECH_SECRET_KEY = process.env.PAYTECH_SECRET_KEY || 'your_secret_key'
const PAYTECH_BASE_URL = 'https://paytech.sn/api/payment/v2'

interface PayTechPaymentRequest {
  item_name: string
  item_price: number
  currency: string
  ref_command: string
  command_name: string
  env: 'test' | 'prod'
  success_url: string
  cancel_url: string
  ipn_url: string
  custom_field?: string
  customer_email?: string
  customer_phone?: string
}

// Initiate PayTech payment
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { 
      amount, 
      type, // 'donation', 'contribution', 'card_fee'
      itemName,
      customerEmail,
      customerPhone,
      memberId,
    } = body

    // Generate reference
    const refCommand = `RR-${type.toUpperCase()}-${Date.now()}`

    // Build payment request
    const paymentData: PayTechPaymentRequest = {
      item_name: itemName || `RR Sunu Reew - ${type}`,
      item_price: amount,
      currency: 'XOF',
      ref_command: refCommand,
      command_name: `Paiement ${type} - RR Sunu Reew`,
      env: process.env.NODE_ENV === 'production' ? 'prod' : 'test',
      success_url: `${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}?payment=success&ref=${refCommand}`,
      cancel_url: `${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}?payment=cancel&ref=${refCommand}`,
      ipn_url: `${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/api/paytech/webhook`,
      custom_field: JSON.stringify({ type, memberId }),
      customer_email: customerEmail,
      customer_phone: customerPhone,
    }

    // Call PayTech API
    const response = await fetch(PAYTECH_BASE_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'API_KEY': PAYTECH_API_KEY,
        'API_SECRET': PAYTECH_SECRET_KEY,
      },
      body: JSON.stringify(paymentData),
    })

    const result = await response.json()

    if (!response.ok) {
      console.error('PayTech error:', result)
      return NextResponse.json({ 
        error: result.message || 'Erreur lors de l\'initialisation du paiement' 
      }, { status: 400 })
    }

    return NextResponse.json({
      success: true,
      redirectUrl: result.redirectUrl,
      token: result.token,
      refCommand,
    })
  } catch (error) {
    console.error('PayTech payment error:', error)
    return NextResponse.json({ 
      error: 'Erreur lors de l\'initialisation du paiement' 
    }, { status: 500 })
  }
}

// Verify payment status
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const token = searchParams.get('token')

    if (!token) {
      return NextResponse.json({ error: 'Token requis' }, { status: 400 })
    }

    // Verify with PayTech
    const response = await fetch(`https://paytech.sn/api/payment/v2/${token}/status`, {
      method: 'GET',
      headers: {
        'API_KEY': PAYTECH_API_KEY,
        'API_SECRET': PAYTECH_SECRET_KEY,
      },
    })

    const result = await response.json()

    return NextResponse.json(result)
  } catch (error) {
    console.error('PayTech verify error:', error)
    return NextResponse.json({ 
      error: 'Erreur lors de la vérification du paiement' 
    }, { status: 500 })
  }
}
