import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// PayTech webhook for IPN (Instant Payment Notification)
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    // Verify this is from PayTech (you should verify the signature in production)
    const { 
      type_event,
      ref_command,
      item_name,
      item_price,
      custom_field,
      client_phone,
      client_email,
    } = body

    console.log('PayTech webhook received:', body)

    // Parse custom field
    const customData = custom_field ? JSON.parse(custom_field) : {}
    const { type: paymentType, memberId } = customData

    // Handle different payment events
    if (type_event === 'sale_complete') {
      // Payment successful
      if (paymentType === 'donation') {
        // Record donation
        await db.donation.create({
          data: {
            memberId: memberId || null,
            amount: parseFloat(item_price),
            donorName: item_name,
            donorEmail: client_email || '',
            donorPhone: client_phone || '',
            paymentMethod: 'paytech',
            paymentRef: ref_command,
            status: 'completed',
          }
        })
      } else if (paymentType === 'contribution' && memberId) {
        // Record contribution
        const month = new Date().toISOString().slice(0, 7) // YYYY-MM
        await db.contribution.create({
          data: {
            memberId,
            amount: parseFloat(item_price),
            month,
            paymentMethod: 'paytech',
            paymentRef: ref_command,
            status: 'completed',
          }
        })
      } else if (paymentType === 'card_fee' && memberId) {
        // Mark card fee as paid
        // You might want to add a card_fee_paid field to Member model
      }
    }

    return NextResponse.json({ received: true })
  } catch (error) {
    console.error('PayTech webhook error:', error)
    return NextResponse.json({ error: 'Webhook processing failed' }, { status: 500 })
  }
}
