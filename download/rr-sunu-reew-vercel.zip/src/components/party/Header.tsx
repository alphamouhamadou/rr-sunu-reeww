'use client'

import { useAppStore } from '@/store/useAppStore'
import { Button } from '@/components/ui/button'
import { Menu, X, User, LogOut, Settings, Sun, Moon } from 'lucide-react'
import { useState } from 'react'
import { useTheme } from 'next-themes'
import Image from 'next/image'

export function Header() {
  const { currentSection, setCurrentSection, member, logout } = useAppStore()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const { theme, setTheme } = useTheme()

  const navItems = [
    { id: 'home' as const, label: 'Accueil' },
    { id: 'news' as const, label: 'Actualités' },
    { id: 'vision' as const, label: 'Notre Vision' },
    { id: 'join' as const, label: 'Adhérer' },
    { id: 'donate' as const, label: 'Faire un Don' },
  ]

  return (
    <header className="sticky top-0 z-50 bg-white dark:bg-gray-900 shadow-md">
      {/* Top bar with party colors */}
      <div className="h-1 party-gradient-full"></div>
      
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <button 
            onClick={() => setCurrentSection('home')}
            className="flex items-center gap-3"
          >
            <div className="w-12 h-12 rounded-full overflow-hidden party-gradient flex items-center justify-center">
              <Image 
                src="/logo.png" 
                alt="RR Sunu Reew" 
                width={48} 
                height={48}
                className="object-cover"
              />
            </div>
            <div className="hidden sm:block">
              <h1 className="font-bold text-[#008751] dark:text-[#4ade80] leading-tight">Renaissance Républicaine</h1>
              <p className="text-xs text-gray-600 dark:text-gray-400">Sunu Reew</p>
            </div>
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => (
              <Button
                key={item.id}
                variant={currentSection === item.id ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setCurrentSection(item.id)}
                className={currentSection === item.id ? 'bg-[#008751] hover:bg-[#006b40]' : ''}
              >
                {item.label}
              </Button>
            ))}
          </nav>

          {/* Right side buttons */}
          <div className="hidden lg:flex items-center gap-2">
            {/* Dark mode toggle */}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              className="rounded-full"
            >
              {theme === 'dark' ? (
                <Sun className="w-4 h-4" />
              ) : (
                <Moon className="w-4 h-4" />
              )}
            </Button>

            {member ? (
              <>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setCurrentSection('member')}
                  className="flex items-center gap-2"
                >
                  <User className="w-4 h-4" />
                  {member.firstName}
                </Button>
                {member.role === 'admin' && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentSection('admin')}
                    className="flex items-center gap-2"
                  >
                    <Settings className="w-4 h-4" />
                    Admin
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={logout}
                  className="text-[#CE1126]"
                >
                  <LogOut className="w-4 h-4" />
                </Button>
              </>
            ) : (
              <Button
                onClick={() => setCurrentSection('login')}
                size="sm"
                className="bg-[#008751] hover:bg-[#006b40]"
              >
                Espace Membre
              </Button>
            )}
          </div>

          {/* Mobile menu button */}
          <Button
            variant="ghost"
            size="sm"
            className="lg:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </Button>
        </div>
      </div>

      {/* Mobile Navigation */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white dark:bg-gray-900 border-t dark:border-gray-700">
          <nav className="container mx-auto px-4 py-4 space-y-2">
            {navItems.map((item) => (
              <Button
                key={item.id}
                variant={currentSection === item.id ? 'default' : 'ghost'}
                className={`w-full justify-start ${currentSection === item.id ? 'bg-[#008751] hover:bg-[#006b40]' : ''}`}
                onClick={() => {
                  setCurrentSection(item.id)
                  setMobileMenuOpen(false)
                }}
              >
                {item.label}
              </Button>
            ))}
            <div className="border-t dark:border-gray-700 pt-4 mt-4 space-y-2">
              {/* Dark mode toggle for mobile */}
              <Button
                variant="ghost"
                className="w-full justify-start"
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              >
                {theme === 'dark' ? (
                  <>
                    <Sun className="w-4 h-4 mr-2" />
                    Mode clair
                  </>
                ) : (
                  <>
                    <Moon className="w-4 h-4 mr-2" />
                    Mode sombre
                  </>
                )}
              </Button>
              
              {member ? (
                <>
                  <Button
                    variant="ghost"
                    className="w-full justify-start"
                    onClick={() => {
                      setCurrentSection('member')
                      setMobileMenuOpen(false)
                    }}
                  >
                    <User className="w-4 h-4 mr-2" />
                    Espace Membre
                  </Button>
                  {member.role === 'admin' && (
                    <Button
                      variant="ghost"
                      className="w-full justify-start"
                      onClick={() => {
                        setCurrentSection('admin')
                        setMobileMenuOpen(false)
                      }}
                    >
                      <Settings className="w-4 h-4 mr-2" />
                      Administration
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    className="w-full justify-start text-[#CE1126]"
                    onClick={() => {
                      logout()
                      setMobileMenuOpen(false)
                    }}
                  >
                    <LogOut className="w-4 h-4 mr-2" />
                    Déconnexion
                  </Button>
                </>
              ) : (
                <Button
                  className="w-full bg-[#008751] hover:bg-[#006b40]"
                  onClick={() => {
                    setCurrentSection('login')
                    setMobileMenuOpen(false)
                  }}
                >
                  Espace Membre
                </Button>
              )}
            </div>
          </nav>
        </div>
      )}
    </header>
  )
}
