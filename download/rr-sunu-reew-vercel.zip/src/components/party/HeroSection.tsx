'use client'

import { useAppStore } from '@/store/useAppStore'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { ChevronRight, Users, Heart, Target, Newspaper, CalendarDays, Mail, Bell, Sparkles, CheckCircle2, Loader2 } from 'lucide-react'
import { useEffect, useState } from 'react'
import Image from 'next/image'
import { toast } from 'sonner'

// Newsletter Section Component
function NewsletterSectionInline() {
  const [email, setEmail] = useState('')
  const [name, setName] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!email || !email.includes('@')) {
      toast.error('Veuillez entrer une adresse email valide')
      return
    }

    setIsLoading(true)

    try {
      const response = await fetch('/api/newsletter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, name })
      })

      const data = await response.json()

      if (data.success) {
        setIsSuccess(true)
        setEmail('')
        setName('')
        toast.success(data.message)
      } else {
        toast.error(data.error || 'Une erreur est survenue')
      }
    } catch {
      toast.error('Erreur de connexion. Veuillez réessayer.')
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <section className="py-20 bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-72 h-72 bg-[#008751] rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-[#FFD100] rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-[#CE1126] rounded-full blur-3xl"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#FFD100]/10 border border-[#FFD100]/20 rounded-full mb-6">
            <Bell className="w-4 h-4 text-[#FFD100]" />
            <span className="text-[#FFD100] text-sm font-medium">Restez informé</span>
          </div>

          {/* Title */}
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Inscrivez-vous à notre <span className="text-[#FFD100]">Newsletter</span>
          </h2>

          {/* Description */}
          <p className="text-gray-300 text-lg mb-8 max-w-xl mx-auto">
            Recevez les dernières actualités, événements et annonces de Renaissance Républicaine Sunu Reew directement dans votre boîte mail.
          </p>

          {/* Form or Success Message */}
          {isSuccess ? (
            <div className="bg-[#008751]/20 border border-[#008751]/30 rounded-2xl p-8 backdrop-blur-sm">
              <div className="w-16 h-16 bg-[#008751] rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle2 className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Inscription réussie !</h3>
              <p className="text-gray-300">
                Merci de rejoindre notre communauté. Vous recevrez bientôt nos actualités.
              </p>
              <Button 
                onClick={() => setIsSuccess(false)}
                variant="outline"
                className="mt-4 border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                Inscrire une autre adresse
              </Button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="flex flex-col sm:flex-row gap-4 max-w-xl mx-auto">
                <Input
                  type="text"
                  placeholder="Votre nom (optionnel)"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="flex-1 bg-white/10 border-gray-700 text-white placeholder-gray-400 focus:border-[#FFD100] focus:ring-[#FFD100]/20 h-12 rounded-xl"
                />
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4 max-w-xl mx-auto">
                <div className="relative flex-1">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    type="email"
                    placeholder="Votre adresse email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-12 bg-white/10 border-gray-700 text-white placeholder-gray-400 focus:border-[#FFD100] focus:ring-[#FFD100]/20 h-12 rounded-xl"
                    required
                  />
                </div>
                
                <Button 
                  type="submit"
                  disabled={isLoading}
                  className="bg-[#FFD100] text-black hover:bg-[#e6bc00] font-semibold h-12 px-8 rounded-xl shadow-lg shadow-yellow-500/20 transition-all hover:shadow-yellow-500/40"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Inscription...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-5 h-5 mr-2" />
                      S'inscrire
                    </>
                  )}
                </Button>
              </div>

              <p className="text-gray-500 text-sm mt-4">
                🔒 Vos données sont protégées. Nous ne partageons jamais vos informations.
              </p>
            </form>
          )}

          {/* Benefits */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mt-12 pt-8 border-t border-gray-700">
            <div className="flex items-center justify-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[#008751]/20 flex items-center justify-center">
                <Mail className="w-5 h-5 text-[#4ade80]" />
              </div>
              <span className="text-gray-300 text-sm">Actualités exclusives</span>
            </div>
            <div className="flex items-center justify-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[#FFD100]/20 flex items-center justify-center">
                <Bell className="w-5 h-5 text-[#FFD100]" />
              </div>
              <span className="text-gray-300 text-sm">Événements en avant-première</span>
            </div>
            <div className="flex items-center justify-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[#CE1126]/20 flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-[#f87171]" />
              </div>
              <span className="text-gray-300 text-sm">Contenus spéciaux</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

interface Article {
  id: string
  title: string
  excerpt: string
  category: string
  createdAt: string
}

interface Event {
  id: string
  title: string
  date: string
  location: string
}

export function HeroSection() {
  const { setCurrentSection } = useAppStore()
  const [featuredArticles, setFeaturedArticles] = useState<Article[]>([])
  const [upcomingEvents, setUpcomingEvents] = useState<Event[]>([])
  const [memberCount, setMemberCount] = useState(0)

  useEffect(() => {
    // Fetch featured articles
    fetch('/api/articles?featured=true&limit=3')
      .then(res => res.json())
      .then(data => setFeaturedArticles(data.articles || []))
      .catch(console.error)

    // Fetch stats
    fetch('/api/stats')
      .then(res => res.json())
      .then(data => setMemberCount(data.members?.total || 0))
      .catch(console.error)

    // Fetch events
    fetch('/api/events?upcoming=true&limit=3')
      .then(res => res.json())
      .then(data => setUpcomingEvents(data.events || []))
      .catch(console.error)
  }, [])

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'short'
    })
  }

  return (
    <div className="animate-fade-in">
      {/* Hero Banner with SG Photo */}
      <section className="relative party-gradient text-white overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="container mx-auto px-4 py-16 md:py-24 relative z-10">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            {/* Left: Text Content */}
            <div className="space-y-6">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 rounded-full backdrop-blur-sm">
                <span className="w-2 h-2 rounded-full bg-[#FFD100] animate-pulse"></span>
                <span className="text-sm font-medium">Ensemble pour le Sénégal</span>
              </div>
              
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
                Renaissance Républicaine<br />
                <span className="text-[#FFD100]">Sunu Reew</span>
              </h1>
              
              <p className="text-xl md:text-2xl text-green-100 max-w-xl">
                Ensemble, construisons un Sénégal prospère, uni et solidaire sous le leadership d'Abdoulaye Diouf Sarr
              </p>
              
              <div className="flex flex-wrap gap-4 pt-4">
                <Button 
                  size="lg" 
                  className="bg-[#FFD100] text-black hover:bg-[#e6bc00] font-semibold shadow-lg shadow-yellow-500/30"
                  onClick={() => setCurrentSection('join')}
                >
                  Rejoindre le parti
                  <ChevronRight className="ml-2 w-5 h-5" />
                </Button>
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="border-white text-white hover:bg-white/10 backdrop-blur-sm"
                  onClick={() => setCurrentSection('vision')}
                >
                  Notre Programme
                </Button>
              </div>
            </div>

            {/* Right: SG Photo */}
            <div className="relative hidden md:block">
              <div className="absolute inset-0 bg-gradient-to-t from-[#008751] via-transparent to-transparent z-10 rounded-2xl"></div>
              <div className="relative w-full aspect-[3/4] max-w-md mx-auto rounded-2xl overflow-hidden shadow-2xl border-4 border-white/20">
                <Image
                  src="/sg-photo.jpg"
                  alt="Abdoulaye Diouf Sarr - Secrétaire Général"
                  fill
                  className="object-cover object-top"
                  priority
                />
                <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black/80 to-transparent z-20">
                  <p className="text-2xl font-bold">Abdoulaye Diouf Sarr</p>
                  <p className="text-[#FFD100] font-medium">Secrétaire Général</p>
                </div>
              </div>
              {/* Decorative elements */}
              <div className="absolute -bottom-4 -right-4 w-32 h-32 bg-[#FFD100] rounded-full opacity-30 blur-2xl"></div>
              <div className="absolute -top-4 -left-4 w-24 h-24 bg-[#CE1126] rounded-full opacity-30 blur-2xl"></div>
            </div>
          </div>
        </div>
        
        {/* Flag stripes at bottom */}
        <div className="absolute bottom-0 left-0 right-0 h-2 flex">
          <div className="flex-1 bg-[#008751]"></div>
          <div className="flex-1 bg-[#FFD100]"></div>
          <div className="flex-1 bg-[#CE1126]"></div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 bg-gray-50 dark:bg-gray-800">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <Card className="text-center border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="pt-6">
                <Users className="w-10 h-10 mx-auto mb-3 text-[#008751]" />
                <div className="text-3xl font-bold text-[#008751]">{memberCount}+</div>
                <p className="text-gray-600 dark:text-gray-400 font-medium">Membres</p>
              </CardContent>
            </Card>
            <Card className="text-center border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="pt-6">
                <Target className="w-10 h-10 mx-auto mb-3 text-[#008751]" />
                <div className="text-3xl font-bold text-[#008751]">14</div>
                <p className="text-gray-600 dark:text-gray-400 font-medium">Régions</p>
              </CardContent>
            </Card>
            <Card className="text-center border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="pt-6">
                <Heart className="w-10 h-10 mx-auto mb-3 text-[#CE1126]" />
                <div className="text-3xl font-bold text-[#CE1126]">100%</div>
                <p className="text-gray-600 dark:text-gray-400 font-medium">Engagement</p>
              </CardContent>
            </Card>
            <Card className="text-center border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="pt-6">
                <Newspaper className="w-10 h-10 mx-auto mb-3 text-[#FFD100]" />
                <div className="text-3xl font-bold text-[#008751]">{featuredArticles.length}</div>
                <p className="text-gray-600 dark:text-gray-400 font-medium">Actualités</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* About SG Section */}
      <section className="py-16 dark:bg-gray-900">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            {/* Mobile SG Photo */}
            <div className="md:hidden relative">
              <div className="aspect-square max-w-xs mx-auto rounded-2xl overflow-hidden shadow-xl party-gradient p-2">
                <div className="w-full h-full rounded-xl overflow-hidden relative">
                  <Image
                    src="/sg-photo.jpg"
                    alt="Abdoulaye Diouf Sarr"
                    fill
                    className="object-cover object-top"
                  />
                </div>
              </div>
            </div>

            <div>
              <div className="inline-block px-4 py-1 bg-[#008751]/10 dark:bg-[#008751]/20 rounded-full text-[#008751] font-semibold text-sm mb-4">
                Le Leadership
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-900 dark:text-white">
                Le Secrétaire Général
              </h2>
              <h3 className="text-2xl font-semibold mb-4 text-[#008751]">
                Abdoulaye Diouf Sarr
              </h3>
              <p className="text-gray-600 dark:text-gray-300 mb-6 leading-relaxed text-lg">
                Figure emblématique de la politique sénégalaise, Abdoulaye Diouf Sarr dirige 
                Renaissance Républicaine Sunu Reew avec une vision claire : bâtir un Sénégal 
                moderne, prospère et solidaire. Son engagement pour le bien-être des populations 
                guide chaque action du parti.
              </p>
              <div className="flex flex-wrap gap-4 mb-6">
                <div className="bg-[#008751]/10 dark:bg-[#008751]/20 rounded-lg px-4 py-2">
                  <div className="text-2xl font-bold text-[#008751]">30+</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Années d'engagement</div>
                </div>
                <div className="bg-[#008751]/10 dark:bg-[#008751]/20 rounded-lg px-4 py-2">
                  <div className="text-2xl font-bold text-[#008751]">14</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Régions parcourues</div>
                </div>
              </div>
              <Button 
                onClick={() => setCurrentSection('vision')}
                className="bg-[#008751] hover:bg-[#006b40]"
              >
                Découvrir notre vision
                <ChevronRight className="ml-2 w-4 h-4" />
              </Button>
            </div>

            {/* Desktop SG Photo */}
            <div className="hidden md:block relative">
              <div className="aspect-[4/5] max-w-md mx-auto rounded-2xl overflow-hidden shadow-2xl">
                <Image
                  src="/sg-photo.jpg"
                  alt="Abdoulaye Diouf Sarr"
                  fill
                  className="object-cover object-top"
                />
              </div>
              <div className="absolute -bottom-4 -right-4 w-32 h-32 bg-[#FFD100] rounded-full opacity-30 blur-2xl"></div>
              <div className="absolute -top-4 -left-4 w-24 h-24 bg-[#CE1126] rounded-full opacity-30 blur-2xl"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Upcoming Events */}
      {upcomingEvents.length > 0 && (
        <section className="py-16 bg-gray-50 dark:bg-gray-800">
          <div className="container mx-auto px-4">
            <div className="flex justify-between items-center mb-8">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Événements à venir</h2>
                <p className="text-gray-600 dark:text-gray-400">Ne manquez aucun événement du parti</p>
              </div>
              <Button variant="outline" onClick={() => setCurrentSection('news')}>
                Voir tout
              </Button>
            </div>
            <div className="grid md:grid-cols-3 gap-6">
              {upcomingEvents.map((event) => (
                <Card key={event.id} className="hover:shadow-lg transition cursor-pointer group">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="bg-[#008751] text-white rounded-lg p-3 text-center min-w-[60px]">
                        <div className="text-2xl font-bold">{formatDate(event.date).split(' ')[0]}</div>
                        <div className="text-xs uppercase">{formatDate(event.date).split(' ')[1]}</div>
                      </div>
                      <div>
                        <h3 className="font-semibold group-hover:text-[#008751] transition">{event.title}</h3>
                        <p className="text-sm text-gray-500 mt-1">{event.location}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Latest News Preview */}
      {featuredArticles.length > 0 && (
        <section className="py-16 dark:bg-gray-900">
          <div className="container mx-auto px-4">
            <div className="flex justify-between items-center mb-8">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Actualités Récentes</h2>
                <p className="text-gray-600 dark:text-gray-400">Restez informé des dernières nouvelles</p>
              </div>
              <Button variant="outline" onClick={() => setCurrentSection('news')}>
                Voir tout
              </Button>
            </div>
            <div className="grid md:grid-cols-3 gap-6">
              {featuredArticles.map((article) => (
                <Card key={article.id} className="hover:shadow-lg transition cursor-pointer group overflow-hidden">
                  <div className="h-2 party-gradient-full"></div>
                  <CardContent className="p-6">
                    <span className="inline-block px-2 py-1 text-xs rounded bg-[#008751]/10 text-[#008751] mb-3">
                      {article.category}
                    </span>
                    <h3 className="font-semibold mb-2 line-clamp-2 group-hover:text-[#008751] transition">
                      {article.title}
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400 text-sm line-clamp-3">{article.excerpt}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Newsletter Section */}
      <NewsletterSectionInline />

      {/* Call to Action */}
      <section className="py-20 party-gradient text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/pattern.svg')] opacity-5"></div>
        <div className="container mx-auto px-4 text-center relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Rejoignez notre mouvement</h2>
          <p className="text-xl text-green-100 mb-8 max-w-2xl mx-auto">
            Ensemble, nous pouvons construire le Sénégal de demain. 
            Adhérez à Renaissance Républicaine Sunu Reew et participez au changement.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button 
              size="lg" 
              className="bg-[#FFD100] text-black hover:bg-[#e6bc00] font-semibold"
              onClick={() => setCurrentSection('join')}
            >
              Devenir membre
              <ChevronRight className="ml-2 w-5 h-5" />
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-white text-white hover:bg-white/10"
              onClick={() => setCurrentSection('donate')}
            >
              Faire un don
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
