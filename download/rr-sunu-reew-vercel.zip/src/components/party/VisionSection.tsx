'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { useAppStore } from '@/store/useAppStore'
import { Building2, Leaf, GraduationCap, Stethoscope, Factory, ArrowRight, Users, CheckCircle } from 'lucide-react'
import Image from 'next/image'

const pillars = [
  {
    icon: GraduationCap,
    title: 'Éducation & Formation',
    description: "Investir dans l'éducation de qualité pour tous, de la maternelle à l'université, avec un accent sur la formation professionnelle pour l'emploi des jeunes.",
    color: 'text-[#008751]',
    bgColor: 'bg-[#008751]/10',
  },
  {
    icon: Stethoscope,
    title: 'Santé pour Tous',
    description: "Garantir l'accès aux soins de santé pour chaque Sénégalais, avec des infrastructures modernes et des programmes de prévention efficaces.",
    color: 'text-[#CE1126]',
    bgColor: 'bg-[#CE1126]/10',
  },
  {
    icon: Leaf,
    title: 'Souveraineté Alimentaire',
    description: 'Moderniser notre agriculture pour nourrir le Sénégal, soutenir nos agriculteurs et réduire notre dépendance aux importations.',
    color: 'text-[#008751]',
    bgColor: 'bg-[#008751]/10',
  },
  {
    icon: Factory,
    title: 'Industrialisation',
    description: "Développer une industrie nationale créatrice d'emplois, valorisant nos ressources locales et compétitive à l'échelle continentale.",
    color: 'text-[#FFD100]',
    bgColor: 'bg-[#FFD100]/10',
  },
  {
    icon: Building2,
    title: 'Infrastructures',
    description: 'Construire des routes, des ponts, des logements et des équipements publics pour connecter toutes les régions et améliorer le cadre de vie.',
    color: 'text-[#008751]',
    bgColor: 'bg-[#008751]/10',
  },
  {
    icon: Users,
    title: 'Cohésion Sociale',
    description: "Renforcer l'unité nationale, promouvoir le dialogue intercommunautaire et garantir l'égalité des chances pour tous les citoyens.",
    color: 'text-[#CE1126]',
    bgColor: 'bg-[#CE1126]/10',
  },
]

const values = [
  { title: 'Démocratie', description: 'Respect des institutions et de la volonté du peuple' },
  { title: 'Transparence', description: 'Gestion rigoureuse et rendu de comptes' },
  { title: 'Solidarité', description: 'Entraide et cohésion sociale' },
  { title: 'Innovation', description: 'Solutions créatives pour les défis de demain' },
]

const achievements = [
  { title: 'Ancien Ministre de la Santé', year: '2012-2019' },
  { title: 'Député à l\'Assemblée Nationale', year: '2007-2012' },
  { title: 'Maire de Fissel', year: '2009-2014' },
  { title: 'Président de Commission', year: 'Multiple mandats' },
]

export function VisionSection() {
  const { setCurrentSection } = useAppStore()

  return (
    <div className="animate-fade-in">
      {/* Hero */}
      <section className="party-gradient text-white py-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Notre Vision pour le Sénégal</h1>
            <p className="text-xl text-green-100">
              Un Sénégal prospère, uni et solidaire, où chaque citoyen peut réaliser son plein potentiel.
            </p>
          </div>
        </div>
      </section>

      {/* SG Biography with Photo */}
      <section className="py-16 dark:bg-gray-900">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="order-2 md:order-1">
              <div className="inline-block px-4 py-1 bg-[#008751]/10 dark:bg-[#008751]/20 rounded-full text-[#008751] font-semibold text-sm mb-4">
                Le Leadership
              </div>
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
                Abdoulaye Diouf Sarr
              </h2>
              <p className="text-lg font-semibold text-[#008751] mb-6">
                Secrétaire Général de Renaissance Républicaine Sunu Reew
              </p>
              
              <div className="space-y-4 text-gray-700 dark:text-gray-300">
                <p className="leading-relaxed">
                  Figure respectée de la politique sénégalaise, Abdoulaye Diouf Sarr consacre 
                  sa vie au service de la nation. Fort d'une expérience politique riche et d'une 
                  connaissance approfondie des réalités du pays, il porte une vision ambitieuse 
                  pour le Sénégal.
                </p>
                <p className="leading-relaxed">
                  Ancien ministre et parlementaire expérimenté, il a œuvré dans plusieurs 
                  domaines clés : santé, affaires sociales, gouvernance locale. Son parcours 
                  témoigne d'un engagement constant pour l'amélioration des conditions de vie 
                  des Sénégalais.
                </p>
                <p className="leading-relaxed">
                  À la tête de Renaissance Républicaine Sunu Reew, il rassemble les énergies 
                  autour d'un projet de société fondé sur le développement inclusif, la justice 
                  sociale et la modernisation de notre économie.
                </p>
              </div>

              {/* Achievements */}
              <div className="mt-8">
                <h3 className="font-semibold text-gray-900 dark:text-white mb-4">Parcours</h3>
                <div className="grid grid-cols-2 gap-3">
                  {achievements.map((item, idx) => (
                    <div key={idx} className="flex items-start gap-2 bg-gray-50 dark:bg-gray-800 rounded-lg p-3">
                      <CheckCircle className="w-5 h-5 text-[#008751] flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-gray-900 dark:text-white">{item.title}</p>
                        <p className="text-xs text-gray-500">{item.year}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-6 flex flex-wrap gap-4">
                <div className="bg-[#008751]/10 dark:bg-[#008751]/20 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-[#008751]">30+</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Années d'engagement</div>
                </div>
                <div className="bg-[#008751]/10 dark:bg-[#008751]/20 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-[#008751]">14</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Régions parcourues</div>
                </div>
              </div>
            </div>

            <div className="order-1 md:order-2">
              <div className="relative max-w-md mx-auto">
                <div className="aspect-[4/5] rounded-2xl overflow-hidden shadow-2xl">
                  <Image
                    src="/sg-photo.jpg"
                    alt="Abdoulaye Diouf Sarr"
                    fill
                    className="object-cover object-top"
                  />
                </div>
                <div className="absolute -bottom-4 -right-4 w-32 h-32 bg-[#FFD100] rounded-full opacity-20 blur-2xl"></div>
                <div className="absolute -top-4 -left-4 w-24 h-24 bg-[#CE1126] rounded-full opacity-20 blur-2xl"></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-16 bg-gray-50 dark:bg-gray-800">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Nos Valeurs</h2>
            <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              Les principes qui guident notre action et définissent notre identité politique
            </p>
          </div>
          
          <div className="grid md:grid-cols-4 gap-6">
            {values.map((value, idx) => (
              <Card key={idx} className="text-center hover:shadow-lg transition border-0 shadow">
                <CardContent className="pt-8 pb-6">
                  <div className="w-12 h-12 rounded-full party-gradient mx-auto mb-4 flex items-center justify-center text-white font-bold">
                    {idx + 1}
                  </div>
                  <h3 className="font-semibold text-lg mb-2 text-[#008751]">{value.title}</h3>
                  <p className="text-gray-600 dark:text-gray-400 text-sm">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Program Pillars */}
      <section className="py-16 dark:bg-gray-900">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Les Piliers de Notre Programme</h2>
            <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              Un programme ambitieux et réaliste pour transformer le Sénégal
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {pillars.map((pillar, idx) => (
              <Card key={idx} className="hover:shadow-lg transition group border-0 shadow">
                <CardContent className="p-6">
                  <div className={`w-14 h-14 rounded-xl ${pillar.bgColor} flex items-center justify-center mb-4 group-hover:scale-110 transition`}>
                    <pillar.icon className={`w-7 h-7 ${pillar.color}`} />
                  </div>
                  <h3 className="font-semibold text-lg mb-2 text-gray-900 dark:text-white">{pillar.title}</h3>
                  <p className="text-gray-600 dark:text-gray-400 text-sm leading-relaxed">{pillar.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 party-gradient text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/pattern.svg')] opacity-5"></div>
        <div className="container mx-auto px-4 text-center relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Rejoignez notre vision</h2>
          <p className="text-xl text-green-100 mb-8 max-w-2xl mx-auto">
            Votre engagement compte. Ensemble, construisons le Sénégal de demain.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button 
              size="lg" 
              className="bg-[#FFD100] text-black hover:bg-[#e6bc00] font-semibold"
              onClick={() => setCurrentSection('join')}
            >
              Adhérer au parti
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-white text-white hover:bg-white/10"
              onClick={() => setCurrentSection('donate')}
            >
              Soutenir financièrement
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
