'use client'

import { useEffect, useState, useRef } from 'react'
import { useAppStore } from '@/store/useAppStore'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  User, CreditCard, MessageSquare, Clock, MapPin, Phone, Mail, 
  Calendar, Download, Eye, CheckCircle, AlertCircle, Loader2,
  ExternalLink, Camera
} from 'lucide-react'
import QRCode from 'qrcode'
import jsPDF from 'jspdf'
import html2canvas from 'html2canvas'

interface Contribution {
  id: string
  amount: number
  month: string
  paymentMethod: string
  paymentRef: string | null
  status: string
  createdAt: string
}

interface Notification {
  id: string
  title: string
  message: string
  type: string
  isRead: boolean
  createdAt: string
}

const CARD_FEE = 2000 // 2000 FCFA for membership card
const MONTHLY_CONTRIBUTION = 5000 // 5000 FCFA monthly

export function MemberSpace() {
  const { member, setCurrentSection, memberSection, setMemberSection } = useAppStore()
  const [qrCode, setQrCode] = useState('')
  const [contributions, setContributions] = useState<Contribution[]>([])
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [loading, setLoading] = useState(true)
  const [paymentLoading, setPaymentLoading] = useState(false)
  const [paymentError, setPaymentError] = useState('')
  const cardRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (member?.membershipNumber) {
      // Generate QR Code
      QRCode.toDataURL(member.membershipNumber, {
        width: 200,
        margin: 2,
        color: { dark: '#008751', light: '#ffffff' }
      }).then(setQrCode)
    }

    const fetchData = async () => {
      if (member?.id) {
        try {
          // Fetch contributions
          const contribRes = await fetch(`/api/contributions?memberId=${member.id}`)
          const contribData = await contribRes.json()
          setContributions(contribData.contributions || [])

          // Fetch notifications
          const notifRes = await fetch(`/api/notifications?memberId=${member.id}`)
          const notifData = await notifRes.json()
          setNotifications(notifData.notifications || [])
        } catch (error) {
          console.error(error)
        }
      }
      setLoading(false)
    }

    fetchData()
  }, [member])

  const initiatePayTechPayment = async (type: 'contribution' | 'card_fee', amount: number) => {
    setPaymentLoading(true)
    setPaymentError('')

    try {
      const res = await fetch('/api/paytech', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount,
          type,
          itemName: type === 'contribution' ? 'Cotisation mensuelle' : 'Carte de membre',
          customerEmail: member?.email,
          customerPhone: member?.phone,
          memberId: member?.id,
        })
      })

      const data = await res.json()

      if (data.redirectUrl) {
        // Open PayTech payment page
        window.open(data.redirectUrl, '_blank')
      } else {
        setPaymentError(data.error || 'Erreur lors de l\'initialisation du paiement')
      }
    } catch (error) {
      console.error(error)
      setPaymentError('Erreur de connexion au service de paiement')
    } finally {
      setPaymentLoading(false)
    }
  }

  const downloadCardAsPDF = async () => {
    if (!cardRef.current || !member) return

    try {
      const canvas = await html2canvas(cardRef.current, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#ffffff'
      })

      const imgData = canvas.toDataURL('image/png')
      const pdf = new jsPDF({
        orientation: 'landscape',
        unit: 'mm',
        format: [85.6, 53.98] // Standard credit card size in mm
      })

      const imgWidth = 85.6
      const imgHeight = 53.98

      pdf.addImage(imgData, 'PNG', 0, 0, imgWidth, imgHeight)
      pdf.save(`carte-membre-${member.membershipNumber}.pdf`)
    } catch (error) {
      console.error('Error generating PDF:', error)
    }
  }

  // Download receipt for a contribution
  const downloadReceipt = async (contributionId: string) => {
    try {
      const response = await fetch('/api/receipts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ contributionId })
      })

      if (!response.ok) {
        throw new Error('Erreur lors de la génération du reçu')
      }

      const blob = await response.blob()
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `recu-cotisation-${contributionId}.pdf`
      document.body.appendChild(a)
      a.click()
      window.URL.revokeObjectURL(url)
      document.body.removeChild(a)
    } catch (error) {
      console.error('Erreur téléchargement reçu:', error)
    }
  }

  const formatAmount = (amount: number) => {
    return new Intl.NumberFormat('fr-SN').format(amount) + ' FCFA'
  }

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })
  }

  const formatMonth = (monthStr: string) => {
    const [year, month] = monthStr.split('-')
    const date = new Date(parseInt(year), parseInt(month) - 1)
    return date.toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' })
  }

  // Check if current month contribution is paid
  const currentMonth = new Date().toISOString().slice(0, 7)
  const currentMonthPaid = contributions.some(c => c.month === currentMonth && c.status === 'completed')

  if (!member) {
    setCurrentSection('login')
    return null
  }

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <Loader2 className="w-8 h-8 animate-spin mx-auto text-[#008751]" />
        <p className="mt-4 text-gray-600 dark:text-gray-400">Chargement...</p>
      </div>
    )
  }

  return (
    <div className="animate-fade-in">
      {/* Header */}
      <section className="party-gradient text-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center text-2xl font-bold">
              {member.firstName[0]}{member.lastName[0]}
            </div>
            <div>
              <h1 className="text-2xl font-bold">
                Bienvenue, {member.firstName} {member.lastName}
              </h1>
              <p className="text-green-100">
                Membre #{member.membershipNumber || 'En attente'}
              </p>
            </div>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 py-8">
        <Tabs value={memberSection} onValueChange={(v) => setMemberSection(v as typeof memberSection)}>
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="profile" className="flex items-center gap-2">
              <User className="w-4 h-4" />
              <span className="hidden sm:inline">Profil</span>
            </TabsTrigger>
            <TabsTrigger value="card" className="flex items-center gap-2">
              <CreditCard className="w-4 h-4" />
              <span className="hidden sm:inline">Carte</span>
            </TabsTrigger>
            <TabsTrigger value="contributions" className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <span className="hidden sm:inline">Cotisations</span>
            </TabsTrigger>
            <TabsTrigger value="messages" className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4" />
              <span className="hidden sm:inline">Messages</span>
            </TabsTrigger>
          </TabsList>

          {/* Profile Tab */}
          <TabsContent value="profile">
            <Card>
              <CardHeader>
                <CardTitle className="text-[#008751]">Mes Informations</CardTitle>
                <CardDescription>Vos informations personnelles</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <User className="w-5 h-5 text-[#008751]" />
                      <div>
                        <p className="text-sm text-gray-500">Nom complet</p>
                        <p className="font-medium dark:text-white">{member.firstName} {member.lastName}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Mail className="w-5 h-5 text-[#008751]" />
                      <div>
                        <p className="text-sm text-gray-500">Email</p>
                        <p className="font-medium dark:text-white">{member.email}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Phone className="w-5 h-5 text-[#008751]" />
                      <div>
                        <p className="text-sm text-gray-500">Téléphone</p>
                        <p className="font-medium dark:text-white">{member.phone}</p>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <MapPin className="w-5 h-5 text-[#008751]" />
                      <div>
                        <p className="text-sm text-gray-500">Région</p>
                        <p className="font-medium dark:text-white">{member.region?.name || 'Non renseignée'}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Calendar className="w-5 h-5 text-[#008751]" />
                      <div>
                        <p className="text-sm text-gray-500">Membre depuis</p>
                        <p className="font-medium dark:text-white">
                          {member.membershipDate ? formatDate(member.membershipDate) : 'En attente'}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <CreditCard className="w-5 h-5 text-[#008751]" />
                      <div>
                        <p className="text-sm text-gray-500">N° de carte</p>
                        <p className="font-medium dark:text-white">{member.membershipNumber || 'En attente de validation'}</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t">
                  <Badge className={
                    member.status === 'approved' ? 'bg-[#008751]' :
                    member.status === 'pending' ? 'bg-[#FFD100] text-black' :
                    'bg-[#CE1126]'
                  }>
                    {member.status === 'approved' ? 'Membre validé' :
                     member.status === 'pending' ? 'En attente de validation' :
                     'Compte rejeté'}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Card Tab */}
          <TabsContent value="card">
            <div className="max-w-md mx-auto space-y-6">
              {/* Digital Member Card - Design amélioré */}
              <div ref={cardRef} className="bg-white rounded-2xl shadow-2xl overflow-hidden">
                {/* Header avec dégradé */}
                <div className="party-gradient p-4 text-white relative">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -mr-16 -mt-16"></div>
                  <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/5 rounded-full -ml-12 -mb-12"></div>
                  
                  <div className="flex justify-between items-start mb-2 relative z-10">
                    <div>
                      <h2 className="text-lg font-bold">Renaissance Républicaine</h2>
                      <p className="text-green-200 text-sm">Sunu Reew</p>
                    </div>
                    <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center font-bold text-sm">
                      RR
                    </div>
                  </div>
                </div>
                
                {/* Contenu principal avec photo et infos */}
                <CardContent className="p-4 bg-white">
                  <div className="flex gap-4">
                    {/* Photo de profil */}
                    <div className="flex-shrink-0">
                      <div className="w-24 h-28 rounded-lg overflow-hidden border-2 border-[#008751]/20 bg-gray-100 flex items-center justify-center shadow-md">
                        {member.photo ? (
                          <img 
                            src={member.photo} 
                            alt="Photo" 
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full bg-gradient-to-b from-[#008751]/10 to-[#008751]/20 flex items-center justify-center">
                            <Camera className="w-8 h-8 text-[#008751]/40" />
                          </div>
                        )}
                      </div>
                    </div>
                    
                    {/* Informations du membre */}
                    <div className="flex-1 space-y-1">
                      <div>
                        <p className="text-xs text-gray-400 uppercase tracking-wide">Nom</p>
                        <p className="font-bold text-gray-900 text-lg leading-tight">{member.firstName} {member.lastName}</p>
                      </div>
                      
                      <div>
                        <p className="text-xs text-gray-400 uppercase tracking-wide">N° Membre</p>
                        <p className="font-semibold text-[#008751]">{member.membershipNumber || 'En attente'}</p>
                      </div>
                      
                      <div>
                        <p className="text-xs text-gray-400 uppercase tracking-wide">Téléphone</p>
                        <p className="text-sm text-gray-700">{member.phone}</p>
                      </div>
                    </div>
                  </div>
                  
                  {/* Localisation */}
                  <div className="mt-4 pt-3 border-t border-gray-100">
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div>
                        <p className="text-xs text-gray-400 uppercase tracking-wide">Département</p>
                        <p className="font-medium text-gray-800">{member.department?.name || member.cityAbroad || 'N/A'}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-400 uppercase tracking-wide">Commune</p>
                        <p className="font-medium text-gray-800">{member.commune?.name || member.country || 'N/A'}</p>
                      </div>
                    </div>
                  </div>
                  
                  {/* Footer avec QR Code et date */}
                  <div className="mt-4 pt-3 border-t border-gray-100 flex items-center justify-between">
                    <div>
                      <p className="text-xs text-gray-400">Membre depuis</p>
                      <p className="text-sm font-medium text-gray-700">
                        {member.membershipDate ? formatDate(member.membershipDate) : 'En attente'}
                      </p>
                    </div>
                    {qrCode && (
                      <div className="qr-container">
                        <img src={qrCode} alt="QR Code" className="w-16 h-16" />
                      </div>
                    )}
                  </div>
                </CardContent>
              </div>

              {paymentError && (
                <Alert className="bg-[#CE1126]/10 border-[#CE1126]">
                  <AlertCircle className="w-4 h-4 text-[#CE1126]" />
                  <AlertDescription className="text-[#CE1126]">{paymentError}</AlertDescription>
                </Alert>
              )}

              {/* Card Actions */}
              <div className="space-y-3">
                {qrCode && (
                  <Button 
                    className="w-full bg-[#008751] hover:bg-[#006b40]"
                    onClick={downloadCardAsPDF}
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Télécharger en PDF
                  </Button>
                )}
                
                <Button 
                  variant="outline"
                  className="w-full"
                  onClick={() => initiatePayTechPayment('card_fee', CARD_FEE)}
                  disabled={paymentLoading}
                >
                  {paymentLoading ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <CreditCard className="w-4 h-4 mr-2" />
                  )}
                  Payer la carte ({formatAmount(CARD_FEE)})
                </Button>
              </div>

              {!qrCode && (
                <Alert>
                  <AlertCircle className="w-4 h-4" />
                  <AlertDescription>
                    Votre carte sera disponible après validation de votre compte
                  </AlertDescription>
                </Alert>
              )}
            </div>
          </TabsContent>

          {/* Contributions Tab */}
          <TabsContent value="contributions">
            <Card>
              <CardHeader>
                <CardTitle className="text-[#008751]">Mes Cotisations</CardTitle>
                <CardDescription>Historique de vos cotisations mensuelles</CardDescription>
              </CardHeader>
              <CardContent>
                {paymentError && (
                  <Alert className="mb-4 bg-[#CE1126]/10 border-[#CE1126]">
                    <AlertCircle className="w-4 h-4 text-[#CE1126]" />
                    <AlertDescription className="text-[#CE1126]">{paymentError}</AlertDescription>
                  </Alert>
                )}

                {/* Current Month Status */}
                <div className={`p-4 rounded-lg mb-6 ${currentMonthPaid ? 'bg-[#008751]/10' : 'bg-[#FFD100]/10'}`}>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium dark:text-white">
                        {currentMonthPaid ? 'Cotisation du mois en cours payée' : 'Cotisation du mois en cours impayée'}
                      </p>
                      <p className="text-sm text-gray-500">
                        {formatMonth(currentMonth)} - {formatAmount(MONTHLY_CONTRIBUTION)}
                      </p>
                    </div>
                    {!currentMonthPaid && (
                      <Button
                        className="bg-[#008751] hover:bg-[#006b40]"
                        onClick={() => initiatePayTechPayment('contribution', MONTHLY_CONTRIBUTION)}
                        disabled={paymentLoading}
                      >
                        {paymentLoading ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          'Payer'
                        )}
                      </Button>
                    )}
                  </div>
                </div>

                {/* Contribution History */}
                {contributions.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <Clock className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p>Aucune cotisation enregistrée</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {contributions.map((contribution) => (
                      <div 
                        key={contribution.id}
                        className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg"
                      >
                        <div className="flex items-center gap-4">
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                            contribution.status === 'completed' ? 'bg-[#008751]/10' : 'bg-[#FFD100]/10'
                          }`}>
                            {contribution.status === 'completed' ? (
                              <CheckCircle className="w-5 h-5 text-[#008751]" />
                            ) : (
                              <Clock className="w-5 h-5 text-[#FFD100]" />
                            )}
                          </div>
                          <div>
                            <p className="font-medium dark:text-white">{formatMonth(contribution.month)}</p>
                            <p className="text-sm text-gray-500 capitalize">
                              {contribution.paymentMethod.replace('_', ' ')}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="text-right">
                            <p className="font-bold text-[#008751]">{formatAmount(contribution.amount)}</p>
                            <Badge variant="outline" className={
                              contribution.status === 'completed' ? 'border-[#008751] text-[#008751]' :
                              'border-[#FFD100] text-[#008751]'
                            }>
                              {contribution.status === 'completed' ? 'Payé' : 'En attente'}
                            </Badge>
                          </div>
                          {contribution.status === 'completed' && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => downloadReceipt(contribution.id)}
                              className="border-[#008751] text-[#008751] hover:bg-[#008751] hover:text-white"
                            >
                              <Download className="w-4 h-4" />
                            </Button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                <div className="mt-6 pt-6 border-t">
                  <Button 
                    className="w-full bg-[#008751] hover:bg-[#006b40]"
                    onClick={() => initiatePayTechPayment('contribution', MONTHLY_CONTRIBUTION)}
                    disabled={paymentLoading}
                  >
                    {paymentLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Traitement...
                      </>
                    ) : (
                      <>
                        <CreditCard className="w-4 h-4 mr-2" />
                        Payer ma cotisation ({formatAmount(MONTHLY_CONTRIBUTION)})
                      </>
                    )}
                  </Button>
                  <p className="text-xs text-center text-gray-500 mt-2">
                    Paiement sécurisé via PayTech (Wave, Orange Money, Carte bancaire)
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Messages Tab */}
          <TabsContent value="messages">
            <Card>
              <CardHeader>
                <CardTitle className="text-[#008751]">Notifications</CardTitle>
                <CardDescription>Messages et annonces de la direction</CardDescription>
              </CardHeader>
              <CardContent>
                {notifications.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <MessageSquare className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p>Aucune notification</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {notifications.map((notification) => (
                      <div 
                        key={notification.id}
                        className={`p-4 rounded-lg border ${
                          notification.isRead ? 'bg-gray-50 dark:bg-gray-800' : 'bg-[#008751]/5 border-[#008751]/20'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-4">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <p className="font-medium dark:text-white">{notification.title}</p>
                              {!notification.isRead && (
                                <Badge className="bg-[#008751] text-xs">Nouveau</Badge>
                              )}
                            </div>
                            <p className="text-gray-600 dark:text-gray-400 text-sm">{notification.message}</p>
                            <p className="text-xs text-gray-400 mt-2">
                              {formatDate(notification.createdAt)}
                            </p>
                          </div>
                          <Button variant="ghost" size="sm">
                            <Eye className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
