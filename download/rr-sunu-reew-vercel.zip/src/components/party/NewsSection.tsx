'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Calendar, ArrowLeft, Share2 } from 'lucide-react'
import { useAppStore } from '@/store/useAppStore'

interface Article {
  id: string
  title: string
  slug: string
  content: string
  excerpt: string
  category: string
  isFeatured: boolean
  createdAt: string
}

const categoryLabels: Record<string, string> = {
  actualite: 'Actualité',
  communique: 'Communiqué',
  evenement: 'Événement',
}

const categoryColors: Record<string, string> = {
  actualite: 'bg-[#008751]',
  communique: 'bg-[#CE1126]',
  evenement: 'bg-[#FFD100] text-black',
}

export function NewsSection() {
  const { setCurrentSection } = useAppStore()
  const [articles, setArticles] = useState<Article[]>([])
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null)
  const [filter, setFilter] = useState<string>('all')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/articles')
      .then(res => res.json())
      .then(data => {
        setArticles(data.articles || [])
        setLoading(false)
      })
      .catch(err => {
        console.error(err)
        setLoading(false)
      })
  }, [])

  const filteredArticles = filter === 'all' 
    ? articles 
    : articles.filter(a => a.category === filter)

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })
  }

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <div className="w-16 h-16 border-4 border-[#008751] border-t-transparent rounded-full animate-spin mx-auto"></div>
        <p className="mt-4 text-gray-600">Chargement des actualités...</p>
      </div>
    )
  }

  if (selectedArticle) {
    return (
      <div className="container mx-auto px-4 py-8 animate-fade-in">
        <Button 
          variant="ghost" 
          className="mb-6"
          onClick={() => setSelectedArticle(null)}
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Retour aux actualités
        </Button>

        <article className="max-w-3xl mx-auto">
          <Badge className={`mb-4 ${categoryColors[selectedArticle.category] || 'bg-gray-500'}`}>
            {categoryLabels[selectedArticle.category] || selectedArticle.category}
          </Badge>
          
          <h1 className="text-3xl font-bold mb-4">{selectedArticle.title}</h1>
          
          <div className="flex items-center gap-4 text-gray-600 mb-8">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              {formatDate(selectedArticle.createdAt)}
            </div>
            <Button variant="ghost" size="sm">
              <Share2 className="w-4 h-4 mr-2" />
              Partager
            </Button>
          </div>

          <div className="prose prose-lg max-w-none">
            {selectedArticle.content.split('\n').map((paragraph, idx) => (
              <p key={idx} className="mb-4 text-gray-700 leading-relaxed">
                {paragraph}
              </p>
            ))}
          </div>
        </article>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 animate-fade-in">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-[#008751] mb-2">Actualités & Communiqués</h1>
        <p className="text-gray-600">Restez informé des dernières nouvelles du parti</p>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-2 mb-8">
        <Button
          variant={filter === 'all' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setFilter('all')}
          className={filter === 'all' ? 'bg-[#008751] hover:bg-[#006b40]' : ''}
        >
          Tous
        </Button>
        {Object.entries(categoryLabels).map(([key, label]) => (
          <Button
            key={key}
            variant={filter === key ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilter(key)}
            className={filter === key ? 'bg-[#008751] hover:bg-[#006b40]' : ''}
          >
            {label}
          </Button>
        ))}
      </div>

      {/* Articles Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredArticles.map((article) => (
          <Card 
            key={article.id}
            className="cursor-pointer hover:shadow-lg transition group"
            onClick={() => setSelectedArticle(article)}
          >
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-3">
                <Badge className={categoryColors[article.category] || 'bg-gray-500'}>
                  {categoryLabels[article.category] || article.category}
                </Badge>
                {article.isFeatured && (
                  <Badge variant="outline" className="border-[#FFD100] text-[#008751]">
                    À la une
                  </Badge>
                )}
              </div>
              
              <h2 className="font-semibold text-lg mb-2 group-hover:text-[#008751] transition">
                {article.title}
              </h2>
              
              <p className="text-gray-600 text-sm line-clamp-3 mb-4">
                {article.excerpt}
              </p>
              
              <div className="flex items-center text-gray-500 text-sm">
                <Calendar className="w-4 h-4 mr-2" />
                {formatDate(article.createdAt)}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredArticles.length === 0 && (
        <div className="text-center py-12 text-gray-500">
          Aucun article trouvé pour cette catégorie.
        </div>
      )}
    </div>
  )
}
