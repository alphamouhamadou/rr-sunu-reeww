'use client'

import { useState, useEffect } from 'react'
import { useAppStore } from '@/store/useAppStore'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Checkbox } from '@/components/ui/checkbox'
import { CheckCircle, User, MapPin, Phone, Mail, FileText, ArrowLeft, Loader2, Globe, Camera, Upload } from 'lucide-react'

interface Region {
  id: string
  name: string
  departments: Department[]
}

interface Department {
  id: string
  name: string
  communes: Commune[]
}

interface Commune {
  id: string
  name: string
}

// Liste des pays de la diaspora sénégalaise
const diasporaCountries = [
  { code: 'FR', name: 'France' },
  { code: 'US', name: 'États-Unis' },
  { code: 'IT', name: 'Italie' },
  { code: 'ES', name: 'Espagne' },
  { code: 'DE', name: 'Allemagne' },
  { code: 'BE', name: 'Belgique' },
  { code: 'GB', name: 'Royaume-Uni' },
  { code: 'CA', name: 'Canada' },
  { code: 'IT', name: 'Italie' },
  { code: 'MA', name: 'Maroc' },
  { code: 'TN', name: 'Tunisie' },
  { code: 'CI', name: 'Côte d\'Ivoire' },
  { code: 'ML', name: 'Mali' },
  { code: 'BF', name: 'Burkina Faso' },
  { code: 'GN', name: 'Guinée' },
  { code: 'MR', name: 'Mauritanie' },
  { code: 'GQ', name: 'Guinée équatoriale' },
  { code: 'GA', name: 'Gabon' },
  { code: 'CG', name: 'Congo' },
  { code: 'CD', name: 'RD Congo' },
  { code: 'AE', name: 'Émirats Arabes Unis' },
  { code: 'SA', name: 'Arabie Saoudite' },
  { code: 'QA', name: 'Qatar' },
  { code: 'CN', name: 'Chine' },
  { code: 'JP', name: 'Japon' },
  { code: 'KR', name: 'Corée du Sud' },
  { code: 'AU', name: 'Australie' },
  { code: 'BR', name: 'Brésil' },
  { code: 'AR', name: 'Argentine' },
  { code: 'OTHER', name: 'Autre pays' },
].sort((a, b) => a.name.localeCompare(b.name))

export function JoinForm() {
  const { setCurrentSection } = useAppStore()
  const [step, setStep] = useState(1)
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState('')
  const [regions, setRegions] = useState<Region[]>([])

  const [formData, setFormData] = useState({
    // Informations personnelles
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: '',
    dateOfBirth: '',
    placeOfBirth: '',
    phone: '',
    address: '',
    
    // Photo de profil (base64)
    photo: '',
    
    // Type de résidence
    residenceType: 'senegal', // senegal ou diaspora
    
    // Pour les résidents au Sénégal
    regionId: '',
    departmentId: '',
    communeId: '',
    
    // Pour la diaspora
    country: '',
    cityAbroad: '',
    
    // Carte d'identité - OBLIGATOIRE
    cniNumber: '',
    
    // Carte d'électeur
    hasVoterCard: false,
    voterCardNumber: '',
  })

  // Get selected region and department
  const selectedRegion = regions.find(r => r.id === formData.regionId)
  const selectedDepartment = selectedRegion?.departments.find(d => d.id === formData.departmentId)

  // Fetch regions on mount
  useEffect(() => {
    fetch('/api/regions')
      .then(res => res.json())
      .then(data => setRegions(data.regions || []))
      .catch(console.error)
  }, [])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }))
  }

  const handleCheckboxChange = (name: string, checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      [name]: checked,
      // Réinitialiser le numéro de carte si décoché
      ...(name === 'hasVoterCard' && !checked ? { voterCardNumber: '' } : {})
    }))
  }

  // Handle photo upload
  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      // Validate file type
      if (!file.type.startsWith('image/')) {
        setError('Veuillez sélectionner une image valide')
        return
      }
      // Validate file size (max 2MB)
      if (file.size > 2 * 1024 * 1024) {
        setError('L\'image ne doit pas dépasser 2 Mo')
        return
      }
      
      // Convert to base64
      const reader = new FileReader()
      reader.onloadend = () => {
        setFormData(prev => ({
          ...prev,
          photo: reader.result as string
        }))
      }
      reader.readAsDataURL(file)
    }
  }

  const validateStep = (currentStep: number): boolean => {
    setError('')
    
    if (currentStep === 1) {
      if (!formData.firstName.trim()) {
        setError('Le prénom est obligatoire')
        return false
      }
      if (!formData.lastName.trim()) {
        setError('Le nom est obligatoire')
        return false
      }
      if (!formData.dateOfBirth) {
        setError('La date de naissance est obligatoire')
        return false
      }
      if (!formData.placeOfBirth.trim()) {
        setError('Le lieu de naissance est obligatoire')
        return false
      }
      if (!formData.email.trim()) {
        setError('L\'email est obligatoire')
        return false
      }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
        setError('Veuillez entrer une adresse email valide')
        return false
      }
      if (!formData.password) {
        setError('Le mot de passe est obligatoire')
        return false
      }
      if (formData.password.length < 6) {
        setError('Le mot de passe doit contenir au moins 6 caractères')
        return false
      }
      if (formData.password !== formData.confirmPassword) {
        setError('Les mots de passe ne correspondent pas')
        return false
      }
    }
    
    if (currentStep === 2) {
      if (!formData.phone.trim()) {
        setError('Le numéro de téléphone est obligatoire')
        return false
      }
      if (!formData.address.trim()) {
        setError('L\'adresse est obligatoire')
        return false
      }
      
      if (formData.residenceType === 'senegal') {
        if (!formData.regionId) {
          setError('La région est obligatoire')
          return false
        }
        if (!formData.departmentId) {
          setError('Le département est obligatoire')
          return false
        }
        if (!formData.communeId) {
          setError('La commune est obligatoire')
          return false
        }
      } else {
        if (!formData.country) {
          setError('Le pays de résidence est obligatoire')
          return false
        }
        if (!formData.cityAbroad.trim()) {
          setError('La ville de résidence est obligatoire')
          return false
        }
      }
    }
    
    if (currentStep === 3) {
      if (!formData.cniNumber.trim()) {
        setError('Le numéro de carte d\'identité est obligatoire')
        return false
      }
      if (formData.hasVoterCard && !formData.voterCardNumber.trim()) {
        setError('Le numéro de carte d\'électeur est obligatoire si vous en possédez une')
        return false
      }
    }
    
    return true
  }

  const handleNextStep = () => {
    if (validateStep(step)) {
      setStep(step + 1)
    }
  }

  const handleSubmit = async () => {
    if (!validateStep(3)) return
    
    setLoading(true)

    try {
      const submitData = {
        ...formData,
        // Ajouter le type de résidence pour différencier
        isDiaspora: formData.residenceType === 'diaspora',
      }

      const res = await fetch('/api/members', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(submitData)
      })

      const data = await res.json()

      if (!res.ok) {
        setError(data.error || 'Une erreur est survenue')
        setLoading(false)
        return
      }

      setSuccess(true)
    } catch (err) {
      setError('Erreur de connexion au serveur')
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  if (success) {
    return (
      <div className="container mx-auto px-4 py-16 animate-fade-in">
        <Card className="max-w-lg mx-auto">
          <CardContent className="pt-8 text-center">
            <div className="w-16 h-16 rounded-full bg-[#008751]/10 flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-8 h-8 text-[#008751]" />
            </div>
            <h2 className="text-2xl font-bold text-[#008751] mb-4">Inscription réussie !</h2>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              Votre demande d'adhésion a été enregistrée avec succès. 
              Notre équipe va examiner votre dossier et valider votre compte sous 48h.
            </p>
            <Alert className="mb-6 bg-[#FFD100]/10 border-[#FFD100]">
              <AlertDescription>
                Vous recevrez un email de confirmation une fois votre compte validé.
              </AlertDescription>
            </Alert>
            <Button 
              className="bg-[#008751] hover:bg-[#006b40]"
              onClick={() => setCurrentSection('home')}
            >
              Retour à l'accueil
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 animate-fade-in">
      <Button 
        variant="ghost" 
        className="mb-6"
        onClick={() => setCurrentSection('home')}
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        Retour
      </Button>

      <div className="max-w-2xl mx-auto">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl text-[#008751]">Adhérer au Parti</CardTitle>
            <CardDescription>
              Rejoignez Renaissance Républicaine Sunu Reew et participez au changement
            </CardDescription>
          </CardHeader>
          <CardContent>
            {/* Progress Steps */}
            <div className="flex items-center justify-between mb-8">
              {[1, 2, 3].map((s) => (
                <div key={s} className="flex items-center">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold ${
                    step >= s 
                      ? 'bg-[#008751] text-white' 
                      : 'bg-gray-200 text-gray-500'
                  }`}>
                    {s}
                  </div>
                  {s < 3 && (
                    <div className={`w-16 h-1 mx-2 ${
                      step > s ? 'bg-[#008751]' : 'bg-gray-200'
                    }`} />
                  )}
                </div>
              ))}
            </div>
            <div className="text-center mb-6 text-sm text-gray-500">
              Étape {step}/3: {
                step === 1 ? 'Informations personnelles' :
                step === 2 ? 'Adresse et localisation' :
                'Documents et validation'
              }
            </div>

            {error && (
              <Alert className="mb-6 bg-[#CE1126]/10 border-[#CE1126]">
                <AlertDescription className="text-[#CE1126]">{error}</AlertDescription>
              </Alert>
            )}

            {/* Step 1: Personal Info */}
            {step === 1 && (
              <div className="space-y-4">
                {/* Photo de profil */}
                <div className="flex flex-col items-center mb-6">
                  <div className="relative">
                    <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-[#008751]/20 bg-gray-100 flex items-center justify-center">
                      {formData.photo ? (
                        <img 
                          src={formData.photo} 
                          alt="Photo de profil" 
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <Camera className="w-12 h-12 text-gray-300" />
                      )}
                    </div>
                    <label className="absolute bottom-0 right-0 w-10 h-10 bg-[#008751] rounded-full flex items-center justify-center cursor-pointer hover:bg-[#006b40] transition-colors">
                      <Upload className="w-5 h-5 text-white" />
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handlePhotoChange}
                        className="hidden"
                      />
                    </label>
                  </div>
                  <p className="text-sm text-gray-500 mt-2">Photo de profil (optionnel)</p>
                  <p className="text-xs text-gray-400">JPG, PNG - Max 2 Mo</p>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="firstName">Prénom *</Label>
                    <Input
                      id="firstName"
                      name="firstName"
                      value={formData.firstName}
                      onChange={handleInputChange}
                      placeholder="Votre prénom"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="lastName">Nom *</Label>
                    <Input
                      id="lastName"
                      name="lastName"
                      value={formData.lastName}
                      onChange={handleInputChange}
                      placeholder="Votre nom"
                      required
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="dateOfBirth">Date de naissance *</Label>
                    <Input
                      id="dateOfBirth"
                      name="dateOfBirth"
                      type="date"
                      value={formData.dateOfBirth}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="placeOfBirth">Lieu de naissance *</Label>
                    <Input
                      id="placeOfBirth"
                      name="placeOfBirth"
                      value={formData.placeOfBirth}
                      onChange={handleInputChange}
                      placeholder="Ville de naissance"
                      required
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="email">Email *</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder="votre@email.com"
                      className="pl-10"
                      required
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="phone">Téléphone *</Label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      placeholder="+221 77 XXX XX XX"
                      className="pl-10"
                      required
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="password">Mot de passe *</Label>
                    <Input
                      id="password"
                      name="password"
                      type="password"
                      value={formData.password}
                      onChange={handleInputChange}
                      placeholder="Min. 6 caractères"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="confirmPassword">Confirmer le mot de passe *</Label>
                    <Input
                      id="confirmPassword"
                      name="confirmPassword"
                      type="password"
                      value={formData.confirmPassword}
                      onChange={handleInputChange}
                      placeholder="Retapez le mot de passe"
                      required
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Step 2: Address & Location */}
            {step === 2 && (
              <div className="space-y-4">
                {/* Type de résidence */}
                <div>
                  <Label className="text-base font-semibold">Résidence *</Label>
                  <div className="grid grid-cols-2 gap-4 mt-2">
                    <button
                      type="button"
                      onClick={() => setFormData(prev => ({ 
                        ...prev, 
                        residenceType: 'senegal',
                        country: '',
                        cityAbroad: ''
                      }))}
                      className={`p-4 border-2 rounded-lg text-center transition ${
                        formData.residenceType === 'senegal' 
                          ? 'border-[#008751] bg-[#008751]/5 text-[#008751]' 
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <MapPin className="w-6 h-6 mx-auto mb-2" />
                      <span className="font-medium">Sénégal</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormData(prev => ({ 
                        ...prev, 
                        residenceType: 'diaspora',
                        regionId: '',
                        departmentId: '',
                        communeId: ''
                      }))}
                      className={`p-4 border-2 rounded-lg text-center transition ${
                        formData.residenceType === 'diaspora' 
                          ? 'border-[#008751] bg-[#008751]/5 text-[#008751]' 
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <Globe className="w-6 h-6 mx-auto mb-2" />
                      <span className="font-medium">Diaspora</span>
                    </button>
                  </div>
                </div>

                <div>
                  <Label htmlFor="address">Adresse complète *</Label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Textarea
                      id="address"
                      name="address"
                      value={formData.address}
                      onChange={handleInputChange}
                      placeholder="Votre adresse complète"
                      className="pl-10"
                      required
                    />
                  </div>
                </div>

                {/* Formulaire Sénégal */}
                {formData.residenceType === 'senegal' && (
                  <>
                    {/* Cascading Region -> Department -> Commune */}
                    <div>
                      <Label>Région *</Label>
                      <Select 
                        value={formData.regionId} 
                        onValueChange={(value) => setFormData(prev => ({ 
                          ...prev, 
                          regionId: value, 
                          departmentId: '', 
                          communeId: '' 
                        }))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Sélectionner une région" />
                        </SelectTrigger>
                        <SelectContent className="max-h-64">
                          {regions.map(region => (
                            <SelectItem key={region.id} value={region.id}>
                              {region.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {formData.regionId && selectedRegion && (
                      <div>
                        <Label>Département *</Label>
                        <Select 
                          value={formData.departmentId} 
                          onValueChange={(value) => setFormData(prev => ({ 
                            ...prev, 
                            departmentId: value, 
                            communeId: '' 
                          }))}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Sélectionner un département" />
                          </SelectTrigger>
                          <SelectContent className="max-h-64">
                            {selectedRegion.departments.map(dept => (
                              <SelectItem key={dept.id} value={dept.id}>
                                {dept.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    )}

                    {formData.departmentId && selectedDepartment && (
                      <div>
                        <Label>Commune *</Label>
                        <Select 
                          value={formData.communeId} 
                          onValueChange={(value) => setFormData(prev => ({ 
                            ...prev, 
                            communeId: value 
                          }))}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Sélectionner une commune" />
                          </SelectTrigger>
                          <SelectContent className="max-h-64">
                            {selectedDepartment.communes.map(commune => (
                              <SelectItem key={commune.id} value={commune.id}>
                                {commune.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    )}

                    {/* Summary of selected location */}
                    {formData.regionId && formData.departmentId && formData.communeId && (
                      <div className="p-4 bg-[#008751]/5 rounded-lg border border-[#008751]/20">
                        <p className="text-sm font-medium text-[#008751] mb-1">Localisation sélectionnée :</p>
                        <p className="text-sm text-gray-700 dark:text-gray-300">
                          {selectedDepartment?.communes.find(c => c.id === formData.communeId)?.name}, {' '}
                          {selectedDepartment?.name}, {' '}
                          {selectedRegion?.name}
                        </p>
                      </div>
                    )}
                  </>
                )}

                {/* Formulaire Diaspora */}
                {formData.residenceType === 'diaspora' && (
                  <>
                    <div>
                      <Label>Pays de résidence *</Label>
                      <Select 
                        value={formData.country} 
                        onValueChange={(value) => setFormData(prev => ({ 
                          ...prev, 
                          country: value 
                        }))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Sélectionner un pays" />
                        </SelectTrigger>
                        <SelectContent className="max-h-64">
                          {diasporaCountries.map(country => (
                            <SelectItem key={country.code} value={country.code}>
                              {country.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="cityAbroad">Ville de résidence *</Label>
                      <Input
                        id="cityAbroad"
                        name="cityAbroad"
                        value={formData.cityAbroad}
                        onChange={handleInputChange}
                        placeholder="Ex: Paris, New York, Milan..."
                        required
                      />
                    </div>
                  </>
                )}
              </div>
            )}

            {/* Step 3: Documents */}
            {step === 3 && (
              <div className="space-y-4">
                {/* Numéro CNI - OBLIGATOIRE */}
                <div>
                  <Label htmlFor="cniNumber">Numéro de Carte Nationale d'Identité (CNI) *</Label>
                  <div className="relative">
                    <FileText className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="cniNumber"
                      name="cniNumber"
                      value={formData.cniNumber}
                      onChange={handleInputChange}
                      placeholder="Ex: 1234567890123"
                      className="pl-10"
                      required
                    />
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    Renseignez le numéro figurant sur votre carte d'identité sénégalaise
                  </p>
                </div>

                {/* Carte d'électeur - CONDITIONNEL */}
                <div className="p-4 border rounded-lg bg-gray-50 dark:bg-gray-800">
                  <div className="flex items-center space-x-3">
                    <Checkbox 
                      id="hasVoterCard"
                      checked={formData.hasVoterCard}
                      onCheckedChange={(checked) => handleCheckboxChange('hasVoterCard', checked as boolean)}
                    />
                    <div className="flex-1">
                      <Label htmlFor="hasVoterCard" className="font-medium cursor-pointer">
                        Possédez-vous une carte d'électeur ?
                      </Label>
                      <p className="text-xs text-gray-500">
                        Cochez cette case si vous disposez d'une carte d'électeur sénégalaise
                      </p>
                    </div>
                  </div>

                  {/* Champ conditionnel pour le numéro de carte d'électeur */}
                  {formData.hasVoterCard && (
                    <div className="mt-4 animate-fade-in">
                      <Label htmlFor="voterCardNumber">Numéro de carte d'électeur *</Label>
                      <Input
                        id="voterCardNumber"
                        name="voterCardNumber"
                        value={formData.voterCardNumber}
                        onChange={handleInputChange}
                        placeholder="Ex: 123456789"
                        required
                      />
                    </div>
                  )}
                </div>

                <Alert className="bg-[#008751]/10 border-[#008751]">
                  <AlertDescription className="text-sm">
                    <strong>Engagement :</strong> En soumettant ce formulaire, vous acceptez les conditions d'adhésion 
                    au parti Renaissance Républicaine Sunu Reew et vous vous engagez à 
                    respecter ses statuts et son règlement intérieur.
                  </AlertDescription>
                </Alert>

                <Alert className="bg-[#FFD100]/10 border-[#FFD100]">
                  <AlertDescription className="text-sm">
                    <strong>Important :</strong> Tous les champs marqués d'un astérisque (*) sont obligatoires.
                    Votre demande sera examinée par notre équipe dans un délai de 48h.
                  </AlertDescription>
                </Alert>
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex justify-between mt-8">
              {step > 1 ? (
                <Button
                  variant="outline"
                  onClick={() => setStep(step - 1)}
                >
                  Précédent
                </Button>
              ) : (
                <div />
              )}

              {step < 3 ? (
                <Button
                  className="bg-[#008751] hover:bg-[#006b40]"
                  onClick={handleNextStep}
                >
                  Suivant
                </Button>
              ) : (
                <Button
                  className="bg-[#008751] hover:bg-[#006b40]"
                  onClick={handleSubmit}
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Inscription...
                    </>
                  ) : (
                    <>
                      <User className="w-4 h-4 mr-2" />
                      Soumettre l'adhésion
                    </>
                  )}
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
