import { create } from 'zustand'
import { persist } from 'zustand/middleware'

interface Member {
  id: string
  email: string
  firstName: string
  lastName: string
  phone: string
  photo: string | null
  role: string
  status: string
  membershipNumber: string | null
  membershipDate: string | null
  residenceType: string
  country: string | null
  cityAbroad: string | null
  region?: { id: string; name: string } | null
  department?: { id: string; name: string } | null
  commune?: { id: string; name: string } | null
}

interface AppState {
  // Navigation
  currentSection: 'home' | 'news' | 'vision' | 'join' | 'donate' | 'login' | 'member' | 'admin'
  setCurrentSection: (section: AppState['currentSection']) => void
  
  // Member space subsections
  memberSection: 'profile' | 'card' | 'contributions' | 'messages'
  setMemberSection: (section: AppState['memberSection']) => void
  
  // Admin subsections
  adminSection: 'members' | 'stats' | 'notifications' | 'reminders' | 'content' | 'events' | 'live'
  setAdminSection: (section: AppState['adminSection']) => void
  
  // Authentication
  member: Member | null
  setMember: (member: Member | null) => void
  logout: () => void
  
  // UI state
  sidebarOpen: boolean
  setSidebarOpen: (open: boolean) => void
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      // Navigation
      currentSection: 'home',
      setCurrentSection: (section) => set({ currentSection: section }),
      
      // Member space
      memberSection: 'profile',
      setMemberSection: (section) => set({ memberSection: section }),
      
      // Admin
      adminSection: 'members',
      setAdminSection: (section) => set({ adminSection: section }),
      
      // Auth
      member: null,
      setMember: (member) => set({ member }),
      logout: () => set({ member: null, currentSection: 'home' }),
      
      // UI
      sidebarOpen: false,
      setSidebarOpen: (open) => set({ sidebarOpen: open }),
    }),
    {
      name: 'rr-sunu-reew-storage',
      partialize: (state) => ({ member: state.member }),
    }
  )
)
