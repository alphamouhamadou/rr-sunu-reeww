// Email Service for RR Sunu Reew
// Utilise l'API Z-AI pour l'envoi d'emails

interface EmailOptions {
  to: string
  subject: string
  html: string
  text?: string
}

interface ReminderData {
  memberName: string
  membershipNumber: string
  email: string
  phone: string
  contributionAmount: number
  monthsOverdue: string[]
  customMessage?: string
}

export async function sendEmail({ to, subject, html, text }: EmailOptions): Promise<boolean> {
  try {
    // Pour un vrai système de production, vous devriez utiliser:
    // - SendGrid, Mailgun, Amazon SES, ou un autre service SMTP
    // Ici nous simulons l'envoi
    
    console.log('📧 Email envoyé à:', to)
    console.log('📌 Sujet:', subject)
    console.log('📄 Contenu HTML:', html.substring(0, 200) + '...')
    
    // En production, décommentez et configurez:
    /*
    const response = await fetch('https://api.sendgrid.com/v3/mail/send', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.SENDGRID_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        personalizations: [{ to: [{ email: to }], subject }],
        from: { email: 'noreply@rrsunureew.sn', name: 'RR Sunu Reew' },
        content: [
          { type: 'text/plain', value: text || '' },
          { type: 'text/html', value: html },
        ],
      }),
    })
    
    return response.ok
    */
    
    return true
  } catch (error) {
    console.error('Erreur envoi email:', error)
    return false
  }
}

export function generateContributionReminderEmail(data: ReminderData): { subject: string; html: string; text: string } {
  const amount = new Intl.NumberFormat('fr-SN').format(data.contributionAmount) + ' FCFA'
  const monthsList = data.monthsOverdue.join(', ')
  
  const subject = 'Rappel: Cotisation(s) en retard - Renaissance Républicaine Sunu Reew'
  
  const html = `
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Rappel de cotisation</title>
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f4f4f4;">
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f4; padding: 20px;">
    <tr>
      <td align="center">
        <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
          
          <!-- Header -->
          <tr>
            <td style="background: linear-gradient(135deg, #008751 0%, #006b40 100%); padding: 30px; text-align: center;">
              <h1 style="margin: 0; color: #ffffff; font-size: 24px;">Renaissance Républicaine</h1>
              <p style="margin: 5px 0 0 0; color: #FFD100; font-size: 18px; font-weight: bold;">Sunu Reew</p>
            </td>
          </tr>
          
          <!-- Content -->
          <tr>
            <td style="padding: 30px;">
              <h2 style="margin: 0 0 20px 0; color: #008751; font-size: 20px;">Rappel de cotisation</h2>
              
              <p style="margin: 0 0 15px 0; color: #333; line-height: 1.6;">
                Bonjour <strong>${data.memberName}</strong>,
              </p>
              
              <p style="margin: 0 0 15px 0; color: #333; line-height: 1.6;">
                Nous espérons que vous allez bien. Nous vous contactons concernant votre cotisation mensuelle 
                au parti Renaissance Républicaine Sunu Reew.
              </p>
              
              <!-- Info box -->
              <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin: 20px 0; background-color: #fff8e6; border-left: 4px solid #FFD100; padding: 15px;">
                <tr>
                  <td>
                    <p style="margin: 0 0 10px 0; color: #333; font-weight: bold;">⚠️ Cotisation(s) non payée(s)</p>
                    <p style="margin: 0; color: #666;">
                      <strong>Période(s):</strong> ${monthsList}<br>
                      <strong>Montant par mois:</strong> ${amount}
                    </p>
                  </td>
                </tr>
              </table>
              
              ${data.customMessage ? `
              <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin: 20px 0; background-color: #f0f0f0; border-radius: 5px; padding: 15px;">
                <tr>
                  <td style="padding: 15px;">
                    <p style="margin: 0; color: #333; font-style: italic;">${data.customMessage}</p>
                  </td>
                </tr>
              </table>
              ` : ''}
              
              <p style="margin: 0 0 15px 0; color: #333; line-height: 1.6;">
                En tant que membre fidèle (N° ${data.membershipNumber}), votre contribution est essentielle 
                pour le bon fonctionnement de notre parti et la réalisation de nos actions sur le terrain.
              </p>
              
              <p style="margin: 0 0 15px 0; color: #333; line-height: 1.6;">
                <strong>Comment régulariser votre situation ?</strong><br>
                Connectez-vous à votre espace membre pour effectuer votre paiement en ligne via :
              </p>
              
              <ul style="margin: 0 0 20px 20px; color: #333; line-height: 1.8;">
                <li>Wave</li>
                <li>Orange Money</li>
                <li>Carte bancaire</li>
              </ul>
              
              <!-- CTA Button -->
              <table role="presentation" width="100%" cellspacing="0" cellpadding="0">
                <tr>
                  <td align="center" style="padding: 20px 0;">
                    <a href="https://rrsunureew.sn" style="display: inline-block; background-color: #008751; color: #ffffff; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-weight: bold;">
                      Accéder à mon espace membre
                    </a>
                  </td>
                </tr>
              </table>
              
              <p style="margin: 20px 0 0 0; color: #666; font-size: 14px; line-height: 1.6;">
                Si vous avez des difficultés ou des questions, n'hésitez pas à contacter notre secrétariat 
                au <strong>+221 33 XXX XX XX</strong> ou par email à <strong>contact@rrsunureew.sn</strong>.
              </p>
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="background-color: #f8f8f8; padding: 20px; text-align: center; border-top: 1px solid #e0e0e0;">
              <p style="margin: 0 0 10px 0; color: #666; font-size: 12px;">
                Renaissance Républicaine Sunu Reew<br>
                Dakar, Sénégal
              </p>
              <p style="margin: 0; color: #999; font-size: 11px;">
                © ${new Date().getFullYear()} RR Sunu Reew. Tous droits réservés.
              </p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
  `
  
  const text = `
Rappel de cotisation - Renaissance Républicaine Sunu Reew

Bonjour ${data.memberName},

Nous espérons que vous allez bien. Nous vous contactons concernant votre cotisation mensuelle au parti Renaissance Républicaine Sunu Reew.

⚠️ Cotisation(s) non payée(s):
Période(s): ${monthsList}
Montant par mois: ${amount}

${data.customMessage ? data.customMessage : ''}

En tant que membre fidèle (N° ${data.membershipNumber}), votre contribution est essentielle pour le bon fonctionnement de notre parti.

Pour régulariser votre situation, connectez-vous à votre espace membre: https://rrsunureew.sn

Modes de paiement acceptés: Wave, Orange Money, Carte bancaire

Pour toute question, contactez-nous au +221 33 XXX XX XX ou contact@rrsunureew.sn

---
Renaissance Républicaine Sunu Reew
Dakar, Sénégal
  `
  
  return { subject, html, text }
}

export function generatePaymentConfirmationEmail(data: {
  memberName: string
  email: string
  amount: number
  paymentType: string
  paymentRef: string
  receiptNumber: string
}): { subject: string; html: string; text: string } {
  const amount = new Intl.NumberFormat('fr-SN').format(data.amount) + ' FCFA'
  
  const subject = 'Confirmation de paiement - ' + data.receiptNumber
  
  const html = `
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Confirmation de paiement</title>
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f4f4f4;">
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f4; padding: 20px;">
    <tr>
      <td align="center">
        <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="background-color: #ffffff; border-radius: 8px; overflow: hidden;">
          
          <!-- Header -->
          <tr>
            <td style="background: linear-gradient(135deg, #008751 0%, #006b40 100%); padding: 30px; text-align: center;">
              <h1 style="margin: 0; color: #ffffff; font-size: 24px;">✅ Paiement confirmé</h1>
            </td>
          </tr>
          
          <!-- Content -->
          <tr>
            <td style="padding: 30px;">
              <p style="margin: 0 0 15px 0; color: #333;">
                Bonjour <strong>${data.memberName}</strong>,
              </p>
              
              <p style="margin: 0 0 20px 0; color: #333;">
                Nous confirmons la réception de votre paiement.
              </p>
              
              <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin: 20px 0; background-color: #f0fff4; border: 1px solid #008751; border-radius: 5px; padding: 15px;">
                <tr>
                  <td style="padding: 15px;">
                    <p style="margin: 0 0 10px 0; color: #333;"><strong>Type:</strong> ${data.paymentType}</p>
                    <p style="margin: 0 0 10px 0; color: #333;"><strong>Montant:</strong> ${amount}</p>
                    <p style="margin: 0 0 10px 0; color: #333;"><strong>Référence:</strong> ${data.paymentRef}</p>
                    <p style="margin: 0; color: #333;"><strong>N° Reçu:</strong> ${data.receiptNumber}</p>
                  </td>
                </tr>
              </table>
              
              <p style="margin: 0 0 15px 0; color: #333;">
                Votre reçu est disponible dans votre espace membre. Vous pouvez le télécharger à tout moment.
              </p>
              
              <p style="margin: 20px 0 0 0; color: #666; font-size: 14px;">
                Merci pour votre soutien à Renaissance Républicaine Sunu Reew !
              </p>
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="background-color: #f8f8f8; padding: 20px; text-align: center;">
              <p style="margin: 0; color: #666; font-size: 12px;">
                Renaissance Républicaine Sunu Reew - Dakar, Sénégal
              </p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
  `
  
  const text = `
Confirmation de paiement - Renaissance Républicaine Sunu Reew

Bonjour ${data.memberName},

Nous confirmons la réception de votre paiement.

Type: ${data.paymentType}
Montant: ${amount}
Référence: ${data.paymentRef}
N° Reçu: ${data.receiptNumber}

Votre reçu est disponible dans votre espace membre.

Merci pour votre soutien !

---
Renaissance Républicaine Sunu Reew
  `
  
  return { subject, html, text }
}
